<?php

// Check if user_id is set in the session
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else {
    $user_id = ''; // Default value if not logged in
}

include_once 'components/connection.php'; // Use include_once to avoid redeclaration

// Only execute queries if user_id is not empty
if (!empty($user_id)) {
    $count_wishlist_items = $conn->prepare("SELECT * FROM `wishlist` WHERE user_id = ?");
    $count_wishlist_items->execute([$user_id]);
    $total_wishlist_items = $count_wishlist_items->rowCount();

    $count_cart_items = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
    $count_cart_items->execute([$user_id]);
    $total_cart_items = $count_cart_items->rowCount();
} else {
    $total_wishlist_items = 0;
    $total_cart_items = 0;
}

// Check if user_name and user_email are set in the session
$user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'Guest';
$user_email = isset($_SESSION['user_email']) ? $_SESSION['user_email'] : 'Not logged in';

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: home.php");
    exit(); // Ensure the script stops executing after the redirect
}
?>
<html>
<header class="header">
    <div class="flex">
        <a href="home.php" class="logo"><img src="image/logo.png"></a>
        <nav class="navbar">
            <a href="home.php">home</a>
            <a href="shop.php">shop</a>
            <a href="resource.php">resource</a>
            <a href="about.php">about us</a>
            <a href="contact.php">contact us</a>
        </nav>
        <div class="icons">
            <i class="bx bxs-user" id="user-btn"></i>
            <a href="wishlist.php" class="wishlist-btn"><i class="bx bx-heart"></i><sup><?=$total_wishlist_items ?></sup></a>
            <a href="cart.php" class="cart-btn"><i class="bx bx-cart-download"></i><sup><?=$total_cart_items ?></sup></a>
            <a href="profile.php" class="setting-btn"><i class="bx bx-cog"></i></a>
            <i class="bx bx-list-plus" id="menu-btn" style="font-size: 2rem;"></i>
        </div>
        <div class="user-box">
            <p>username : <span><?php echo $user_name; ?></span></p>
            <p>Email : <span><?php echo $user_email; ?></span></p>
            <a href="login.php" class="btn" style="color: #000;">login</a>
            <a href="register.php" class="btn" style="color: #000;">register</a>
            <form method="post">
                <button type="submit" name="logout" class="logout-btn">logout</button>
            </form>
        </div>
    </div>
</header>
</html>