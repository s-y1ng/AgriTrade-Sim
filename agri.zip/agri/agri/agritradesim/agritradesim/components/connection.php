<?php
    $db_name = 'mysql:host=localhost;dbname=agri';
    $db_user = 'root';
    $db_password ='';

    try {
        $conn = new PDO($db_name,$db_user,$db_password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
    }

    function unique_id(){
        $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charLength = strLen($chars);
        $randomString = '';
        for ($i=0; $i < 20 ; $i++) {
            $randomString.=$chars[mt_rand(0, $charLength -1)];
        }
        return $randomString;
    }
?>