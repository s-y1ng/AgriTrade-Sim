<div class="top-footer">
    <h2><i class="bx bx-envelope"></i>Sign Up For Newsletter</h2>
    <div class="input-field">
        <input type="text" name="" placeholder="email address...">
        <button class="btn">subscribe</button>
    </div>
</div>
<footer>
    <div class="overlay"></div>
    <div class="footer-content">
        <div class="img-box">
            <img src="image/logo.png">
        </div>
        <div class="inner-footer">
            <div class="card">
                <h3>about us</h3>
                <u1>
                    <li>about us</li>
                    <li>our difference</li>
                    <li>community matters</li>
                    <li>press</li>
                    <li>blog</li>
                    <li>bouqs video</li>
                </u1>
            </div>
            <div class="card">
                <h3>services</h3>
                <u1>
                    <li>order</li>
                    <li>help center</li>
                    <li>shipping</li>
                    <li>term of use</li>
                    <li>account detail</li>
                    <li>my account</li>
                </u1>
            </div>
            <div class="card">
                <h3>local</h3>
                <u1>
                    <li>kuala lumpur</li>
                    <li>selangor</li>
                    <li>johor</li>
                    <li>penang</li>
                    <li>perak</li>
                    <li>melacca</li>
                </u1>
            </div>
            <div class="card">
                <h3>newsletter</h3>
                <p>Sign Up For Newsletter</p>
                <div class="social-links">
                    <i class="bx bxl-instagram"></i>
                    <i class="bx bxl-twitter"></i>
                    <i class="bx bxl-facebook"></i>
                    <i class="bx bxl-youtube"></i>
                    <i class="bx bxl-whatsapp"></i>
                </div>
            </div>
        </div>
        <div class="bottom-footer">
            <p>all right reserved - agritrade & sim</p>
        </div>
    </div>
</footer>